<!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.5.3/dist/css/bootstrap.min.css" integrity="sha384-TX8t27EcRE3e/ihU7zmQxVncDAy5uIKz4rEkgIXeMed4M0jlfIDPvg6uqKI2xXr2" crossorigin="anonymous">

    <title>Hello, world!</title>
  </head>
  <body>
    
  <nav class="navbar navbar-expand-lg navbar-light bg-light">
  <a class="navbar-brand" href="#">Navbar</a>
  <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
    <span class="navbar-toggler-icon"></span>
  </button>
  <div class="collapse navbar-collapse" id="navbarNav">
    <ul class="navbar-nav">
      <li class="nav-item active">
        <a class="nav-link" href="#">Home <span class="sr-only">(current)</span></a>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="#">Features</a>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="#">Pricing</a>
      </li>
      <li class="nav-item">
        <a class="nav-link disabled" href="#" tabindex="-1" aria-disabled="true">Disabled</a>
      </li>
    </ul>
  </div>
</nav>
<hr>
<h2> ANTRIAN PENDAFTARAN REKAM MEDIK RAWAT JALAN PUSKESMAS </h2>
<table border="1">
        <tr>
            <th> No Daftar </th>
            <th> No RM </th>
            <th> Nama Pasien </th>
            <th> Tanggal Daftar </th>
            <th> Jam Periksa </th>
            <th> Keluhan Pasien </th>
            <th> Nama Poli </th>
            <th> Nomor Antrian </th>  
        </tr>

        <tr>
            <td> 001 </td>
            <td> RM002 </td>
            <td> ayu </td>
            <td> 10-11-2020 </td>
            <td> 09.00 </td>
            <td> pilek </td>
            <td> poli umum </td>
            <td> 1 </td>

        <tr>
            <td> 002 </td>
            <td> RM003 </td>
            <td> aldi </td>
            <td> 11-11-2020 </td>
            <td> 09.05 </td>
            <td> batuk </td>
            <td> poli umum </td>
            <td> 2 </td>

        <tr>
            <td> 003 </td>
            <td> RM004 </td>
            <td> pitri </td>
            <td> 12-11-2020 </td>
            <td> 09.10 </td>
            <td> pusing </td>
            <td> poli umum </td>
            <td> 3 </td>
        <tr>
            <td> 004 </td>
            <td> RM005 </td>
            <td> bayu </td>
            <td> 13-11-2020 </td>
            <td> 09.15 </td>
            <td> mual </td>
            <td> poli umum </td>
            <td> 4 </td>
        <tr>
            <td> 005 </td>
            <td> RM006 </td>
            <td> sinta </td>
            <td> 14-11-2020 </td>
            <td> 09.20 </td>
            <td> ispa </td>
            <td> poli umum </td>
            <td> 5</td>

        <tr>
            <td> 006 </td>
            <td> RM007 </td>
            <td> apip </td>
            <td> 15-11-2020 </td>
            <td> 09.25 </td>
            <td> DBD </td>
            <td> poli umum </td>
            <td> 6 </td>

        <tr>
            <td> 007 </td>
            <td> RM008 </td>
            <td> sisil </td>
            <td> 16-11-2020 </td>
            <td> 09.30 </td>
            <td> demam </td>
            <td> poli umum </td>
            <td> 7 </td>

            <tr>
            <td> 008 </td>
            <td> RM009 </td>
            <td> adi </td>
            <td> 17-11-2020 </td>
            <td> 09.35 </td>
            <td> diare </td>
            <td> poli umum </td>
            <td> 8</td>

        <tr>
            <td> 009 </td>
            <td> RM0010 </td>
            <td> pitri </td>
            <td> 18-11-2020 </td>
            <td> 09.40 </td>
            <td> maag </td>
            <td> poli umum </td>
            <td> 9 </td>

        <tr>
            <td> 0010 </td>
            <td> RM0011 </td>
            <td> dendi </td>
            <td> 19-11-2020 </td>
            <td> 09.45 </td>
            <td> mual pusing </td>
            <td> poli umum </td>
            <td> 10 </td>

        </tr>
    </table>
    <!-- Optional JavaScript; choose one of the two! -->

    <!-- Option 1: jQuery and Bootstrap Bundle (includes Popper) -->
    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js" integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.5.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-ho+j7jyWK8fNQe+A12Hb8AhRq26LrZ/JpcUGGOn+Y7RsweNrtN/tE3MoK7ZeZDyx" crossorigin="anonymous"></script>

    <!-- Option 2: jQuery, Popper.js, and Bootstrap JS
    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js" integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.1/dist/umd/popper.min.js" integrity="sha384-9/reFTGAW83EW2RDu2S0VKaIzap3H66lZH81PoYlFhbGU+6BZp6G7niu735Sk7lN" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.5.3/dist/js/bootstrap.min.js" integrity="sha384-w1Q4orYjBQndcko6MimVbzY0tgp4pWB4lZ7lr30WKz0vr/aWKhXdBNmNb5D92v7s" crossorigin="anonymous"></script>
    -->
  </body>
</html>